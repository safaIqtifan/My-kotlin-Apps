package com.example.webservice;

public class data {

    private String case_number;
    private String case_age;
    private String case_gender;
    private String case_location;
    private String case_diagnose_date;
    private String case_source_of_infection;
    private String case_condition;
    private String case_quarantine;
    private String case_community;


    public data() {
    }

    public data(String case_number, String case_age, String case_gender, String case_location, String case_diagnose_date, String case_source_of_infection, String case_condition, String case_quarantine, String case_community) {
        this.case_number = case_number;
        this.case_age = case_age;
        this.case_gender = case_gender;
        this.case_location = case_location;
        this.case_diagnose_date = case_diagnose_date;
        this.case_source_of_infection = case_source_of_infection;
        this.case_condition = case_condition;
        this.case_quarantine = case_quarantine;
        this.case_community = case_community;
    }


    public String getCase_number() {
        return case_number;
    }

    public void setCase_number(String case_number) {
        this.case_number = case_number;
    }

    public String getCase_age() {
        return case_age;
    }

    public void setCase_age(String case_age) {
        this.case_age = case_age;
    }

    public String getCase_gender() {
        return case_gender;
    }

    public void setCase_gender(String case_gender) {
        this.case_gender = case_gender;
    }

    public String getCase_location() {
        return case_location;
    }

    public void setCase_location(String case_location) {
        this.case_location = case_location;
    }

    public String getCase_diagnose_date() {
        return case_diagnose_date;
    }

    public void setCase_diagnose_date(String case_diagnose_date) {
        this.case_diagnose_date = case_diagnose_date;
    }

    public String getCase_source_of_infection() {
        return case_source_of_infection;
    }

    public void setCase_source_of_infection(String case_source_of_infection) {
        this.case_source_of_infection = case_source_of_infection;
    }

    public String getCase_condition() {
        return case_condition;
    }

    public void setCase_condition(String case_condition) {
        this.case_condition = case_condition;
    }

    public String getCase_quarantine() {
        return case_quarantine;
    }

    public void setCase_quarantine(String case_quarantine) {
        this.case_quarantine = case_quarantine;
    }

    public String getCase_community() {
        return case_community;
    }

    public void setCase_community(String case_community) {
        this.case_community = case_community;
    }
}
