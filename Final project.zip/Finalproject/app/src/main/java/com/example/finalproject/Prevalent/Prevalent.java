package com.example.finalproject.Prevalent;

import com.example.finalproject.Model.Users;

public class Prevalent {

    public static Users currentOnlineUser;

    public static final String UserPhoneKey = "UserPhone";
    public static final String UserPasswordKey = "UserPassword";
}

