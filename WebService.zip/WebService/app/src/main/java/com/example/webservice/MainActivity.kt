package com.example.webservice

import android.app.ProgressDialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.VolleyError
import com.android.volley.toolbox.JsonArrayRequest
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import kotlinx.android.synthetic.main.activity_main.*
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject


class MainActivity : AppCompatActivity() {

    val URL_ARR = "https://corona.ps/API/cases"
    lateinit var progressDialog: ProgressDialog
    //lateinit var dataList: MutableList<data>
    lateinit var adapter: Adapter
    lateinit var recyclerView: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        recyclerView = findViewById(R.id.list)
        //dataList = ArrayList()
        extractMyData()


    }



    private fun extractMyData() {

        progressDialog = ProgressDialog(this@MainActivity)
        progressDialog.setMessage("Loading data ....")
        progressDialog.setCancelable(false)
        progressDialog.show()

        val queue = Volley.newRequestQueue(this)
        Log.e("tag", "Response: ")
        //val jsonArrayRequest = JsonArrayRequest(Request.Method.GET, JSON_URL, null, Response.Listener<JSONArray> {
        val stringRequest  = StringRequest(Request.Method.GET, JSON_URL, Response.Listener<String>() {response ->
            Log.e("tag", "ok Response: ")

           // fun onResponse(response:String) {
                Log.e("tag", response)
                if (progressDialog.isShowing)
                    progressDialog.dismiss()
            Log.e("tag", "AA")
                var dataList = ArrayList<data>()
            Log.e("tag", "BB")
                    try {
                        Log.e("tag", "CC")
                        val jsonObject = JSONObject(response)
                        val jsonObject2 = jsonObject.getJSONObject("data")
                        Log.e("tag", jsonObject2.toString())
                        val arr = jsonObject2.getJSONArray("cases")
                        Log.e("tag", "B ")
                        for (i in 0 until 20){
                            Log.e("tag", "C ")
                            val Object = arr.getJSONObject(i)
                            Log.e("tag", "D ")
                            val myData = data()
                            myData.setCase_number(Object.getString("case_number"))
                            myData.setCase_age(Object.getString("case_age"))
                            myData.setCase_gender(Object.getString("case_gender"))
                            myData.setCase_location(Object.getString("case_location").toString())
                            myData.setCase_diagnose_date(Object.getString("case_diagnose_date").toString())
                            myData.setCase_source_of_infection(Object.getString("case_source_of_infection").toString())
                            myData.setCase_condition(Object.getString("case_condition").toString())
                            myData.setCase_quarantine(Object.getString("case_quarantine").toString())
                            myData.setCase_community(Object.getString("case_community").toString())

                            dataList.add(myData)

                        }

                        recyclerView.setLayoutManager(LinearLayoutManager(getApplicationContext()))
                        adapter = Adapter(getApplicationContext(), dataList)
                        recyclerView.setAdapter(adapter)

                    }
                    catch (e: JSONException) {
                        e.printStackTrace()
                    }
           //     }

        }, Response.ErrorListener {
             fun onErrorResponse(error: VolleyError) {
                Log.e("tag", "onErrorResponse: " + error.message)
            }
        })
        queue.add(stringRequest)
    }
    companion object {
        private val JSON_URL = "https://corona.ps/API/cases"
    }

}

//    fun getJSONArray(){
//
//        val jsonObjectRequest = JsonObjectRequest(Request.Method.GET,URL_ARR,null,
//            Response.Listener { response ->
//                Log.e("sa",response.toString())
//
//                    val data = response.getString("data")
//
////                val jsonArrayRequest = JsonArrayRequest(Request.Method.GET,URL_ARR,null,
////                    Response.Listener { response ->
////                        Log.e("sa",response.toString())
//

//
////                    },
////                    Response.ErrorListener { error ->
////                        Log.e("sa Error","Error Massage")
////                    })
////
////
//            },
//            Response.ErrorListener { error ->
//                Log.e("sa Error","Error Massage")
//            })
//
//
//
//        MySinleton.getInstance()!!.addRequestQueue(jsonObjectRequest)
//
//
//
//    }
//
//    override fun onPause() {
//        super.onPause()
//        if (progressDialog.isShowing)
//            progressDialog.dismiss()
//    }
//
//}
//
////        btnStart.setOnClickListener {
////
////            progressDialog = ProgressDialog(this@MainActivity)
////            progressDialog.setMessage("Loading data ....")
////            progressDialog.setCancelable(false)
////            progressDialog.show()
////
////            getArr()
////
////        }
//
//
//        //            tvMsg.text = result
////            if (progressDialog.isShowing)
////                progressDialog.dismiss()
//
//
//
