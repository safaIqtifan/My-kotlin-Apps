package com.example.webservice;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class Adapter extends RecyclerView.Adapter<Adapter.ViewHolder>{

    LayoutInflater inflater;
    List<data> dataList;

    public Adapter(Context ctx, List<data> dataList){
        this.inflater = LayoutInflater.from(ctx);
        this.dataList = dataList;
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = inflater.inflate(R.layout.custom_list_layout,parent,false);
        return new ViewHolder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        // bind the data
        holder.case_number.setText(dataList.get(position).getCase_number());
        holder.case_age.setText(dataList.get(position).getCase_age());
        holder.case_gender.setText(dataList.get(position).getCase_gender());
        holder.case_locatio.setText(dataList.get(position).getCase_location());
        holder.case_diagnose_date.setText(dataList.get(position).getCase_diagnose_date());
        holder.case_source_of_infection.setText(dataList.get(position).getCase_source_of_infection());
        holder.case_condition.setText(dataList.get(position).getCase_condition());
        holder.case_quarantine.setText(dataList.get(position).getCase_quarantine());
        holder.case_community.setText(dataList.get(position).getCase_community());


    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    public  class ViewHolder extends  RecyclerView.ViewHolder{
        TextView case_number ,case_age ,case_gender ,
                case_locatio ,case_diagnose_date,
                case_source_of_infection ,case_condition ,
                case_quarantine ,case_community;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            case_number = itemView.findViewById(R.id.textView);
            case_age = itemView.findViewById(R.id.textView2);
            case_gender = itemView.findViewById(R.id.textView3);
            case_locatio = itemView.findViewById(R.id.textView4);
            case_diagnose_date = itemView.findViewById(R.id.textView5);
            case_source_of_infection = itemView.findViewById(R.id.textView6);
            case_condition = itemView.findViewById(R.id.textView7);
            case_quarantine = itemView.findViewById(R.id.textView8);
            case_community = itemView.findViewById(R.id.textView9);

            // handle onClick

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(v.getContext(), "Do Something With this Click", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
}