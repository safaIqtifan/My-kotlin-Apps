package com.example.webservice

import android.app.Application
import android.text.TextUtils
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.toolbox.Volley

class MySinleton : Application(){

    val TAG = "safa"
    private var mRequestQueue : RequestQueue?=null

    companion object{

        private var mInstance:MySinleton? =null

        fun getInstance() : MySinleton?{
            return mInstance
        }
    }

    override fun onCreate() {
        super.onCreate()
        mInstance = this
    }

    private fun getRequestQueue() : RequestQueue?{

        if(mRequestQueue==null){
            mRequestQueue = Volley.newRequestQueue(this)
        }
        return mRequestQueue
    }



    fun <T> addRequestQueue(req : Request<T>, tag:String){
        req.tag = if (TextUtils.isEmpty(tag)) TAG else tag
        getRequestQueue()!!.add(req)
    }


    fun <T> addRequestQueue(req : Request<T>){
        req.tag=TAG
        getRequestQueue()!!.add(req)
    }

    fun cancelPendingRequest(tag: Any?){
        if (mRequestQueue!=null){
            mRequestQueue!!.cancelAll(tag)
        }
    }


}