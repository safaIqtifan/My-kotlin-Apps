package com.example.home1

import android.content.ContentValues
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_main.button3
import kotlinx.android.synthetic.main.activity_main.textView1
import kotlinx.android.synthetic.main.activity_main.textView2
import kotlinx.android.synthetic.main.activity_main2.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val helper = MyDBHelper(this, "User", 1)
        val db = helper.writableDatabase

        button3.setOnClickListener {

            val serviceIntent = Intent(this,MyService::class.java)
            serviceIntent.putExtra("password",textView2.getText().toString())
            serviceIntent.putExtra("name",textView1.getText().toString())
            startService(serviceIntent)

        }

        button5.setOnClickListener {

            val i = Intent(this,MainActivity2::class.java)
            startActivity(i)

        }


        button3.setOnClickListener {

            val name = textView1.getText().toString()
            val password = textView2.getText().toString()

            val cv = ContentValues()
            cv.put("name", name)
            cv.put("password", password)
            val r = db.insert("User", null, cv)

            db.close()


            val intent = Intent(this,MainActivity2::class.java)
            startActivity(intent)

        }


    }
}