package com.example.home1;

import android.app.Notification;
import android.app.Service;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.IBinder;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import static com.example.home1.App.CHANNEL_ID;

public class MyService extends Service {

    MyDBHelper helper = new MyDBHelper(this, "User", 1);
    SQLiteDatabase db = helper.getReadableDatabase();


    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        String input = intent.getStringExtra("name");
        String input2 = intent.getStringExtra("password");
        db.execSQL("SELECT name FROM User WHERE name=input");
        db.execSQL("SELECT password FROM User WHERE name=input2");


        Notification notification = new NotificationCompat.Builder(this , CHANNEL_ID)
                .setContentTitle("Example Service")
                .setContentText(input)
                .setSmallIcon(R.drawable.ic_android)
                .build();

        startForeground(1, notification);

        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {

        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent)
    {
        return null;
    }
}
